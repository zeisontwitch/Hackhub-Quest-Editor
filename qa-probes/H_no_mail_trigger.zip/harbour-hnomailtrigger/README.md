# The Harbour Manifest

A shipping company keeps a manifest it should not. Find the server, get in, and send the client a copy.

## Install (no coding needed)

1. Copy this whole folder into the game's `mods/` directory.
2. Start HackHub — the mod loads from `dist/mod.js`.

## Rebuild (optional, for programmers)

`src/index.ts` is the same code as `dist/mod.js`. With Node 18+:

```
npm install
npm run build
```

## What the editor compiled for you

- Quests: HarbourHnomailtrigger
- Websites: harbourline-logistics.com
- Permissions requested: network, shell, mail, events, bank

## Notes

- HarbourHnomailtrigger: this network claims the domain “harbourline-logistics.com”. Domain names are shared with the whole game, so if the base game or another installed mod already uses one, that one wins and your server will not answer to it. A name nobody else is likely to pick — something tied to your own story — is the safest choice.
- harbourline-logistics.com: 1 unlisted page (/files/internal/q3-audit). Nothing links to it and the in-game search will not show it, so the player reaches it only by typing the address or by running dirhunter on the host — which is exactly what makes a good hiding place for a clue. If you meant this to be findable normally, turn on “Listed in search” for the page.
