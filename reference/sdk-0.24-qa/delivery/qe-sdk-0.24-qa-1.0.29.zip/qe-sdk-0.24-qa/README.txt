QE SDK 0.24 QA Harness 1.0.29 - THE DECISIVE PAIR (r221)

Install (replace the old folder - it is abandonable-friendly now), restart,
open Hackhub, ONE look:

  HF1..HF10  the grid that all rendered last time (fresh names)
  HF11       "QEHhCls1029"    - the editor's exact structural twin
  HF12       "QEHhRenamed1029" - same, but the class carries its own name

The theory: the engine keys quest identity on the CLASS's name. Every editor
quest compiled as class "cls"; one was claimed from the feed on 2026-09-21 -
which would retire EVERY editor export's post on this profile since.

  HF11 ABSENT + HF12 PRESENT -> theory CONFIRMED (and the editor is fixed).
  HF11 PRESENT               -> theory dead.
  both absent                -> re-run on a fresh save first.

Optional: `qe24 feed` prints this. Accepted strays: qe24 run clear, or
abandon them from the journal (every probe is abandonable now).
