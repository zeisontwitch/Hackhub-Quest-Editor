QE SDK 0.24 QA Harness 1.0.28 — the editor-clone grid (r220)

Install BOTH mods this session (replace the old folders), then restart:
  - this folder: qe-sdk-0.24-qa (posts HF1..HF10)
  - qe24-feedcanary (the canary, post HC1)

The test needs NO command:
  1. Open the Hackhub app.
  2. Note which of HF1..HF10 and HC1 are on the feed.
  3. For HF5 specifically: is the poster "Ada Bakker" or "Hidden User"?
Optional: `qe24 feed` prints the cheat sheet.
Optional: accept ONE post afterwards (HF1 is enough) - the log should print
  "[qe24] QEHhBare1028 started from the feed claim".
Cleanup: `qe24 run clear`.

Rows HF1..HF4 = last session's controls (all rendered).
HF5 = employer fallback with the SDK's real employer shape.
HF6..HF9 = one editor assignment each (AutoComplete / HasCompleteButton /
           Abandonable / zero Rewards).
HF10 = the full editor clone (all of them + Group "side" + the employer).
HC1 = the canary: a bare post from a mod with the editor's exact manifest
      (apiVersion 1, permissions mail+events).

Reading:
  one of HF6..HF9 missing          -> THAT editor field kills the post.
  HF10 missing, HF6..HF9 all there -> a joint effect; next grid bisects.
  all ten present, HC1 missing     -> the manifest shape is the killer.
  everything present               -> the editor's compiled runtime is the
                                      last suspect standing.
