# HHFeed Test v6

6th HHFeed Test

## Install (no coding needed)

1. Copy this whole folder into the game's `mods/` directory.
2. Start HackHub — the mod loads from `dist/mod.js`.

## Rebuild (optional, for programmers)

`src/index.ts` is the same code as `dist/mod.js`. With Node 18+:

```
npm install
npm run build
```

## What the editor compiled for you

- Quests: HHFeedTest6
- Websites: none
- Permissions requested: mail, events

## Notes

- Hackhub Feed Test 6: the player claims this one from its Hackhub feed post — nothing in it runs until they do. Turn on “Start automatically” in the quest's Behaviour settings if it should begin the moment the mod loads. Field evidence (r218): the only feed post we have ever seen render is a bare one — post text only, poster and employer left empty, no comments. If the post never shows up in game, strip it to that (and give the quest an identifier it has never had) before anything else.
