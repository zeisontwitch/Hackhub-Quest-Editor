# The Harbour Manifest2

r70 | A shipping company keeps a manifest it should not. Find the server, get in, and send the client a copy.

## Install (no coding needed)

1. Copy this whole folder into the game's `mods/` directory.
2. Start HackHub — the mod loads from `dist/mod.js`.

## Rebuild (optional, for programmers)

`src/index.ts` is the same code as `dist/mod.js`. With Node 18+:

```
npm install
npm run build
```

## What the editor compiled for you

- Quests: TheHarbourManifest2
- Websites: harbourline-logistics.com
- Permissions requested: network, shell, mail, events, bank

## Notes

- harbourline-logistics.com: 1 unlisted page (/files/internal/q3-audit). Nothing links to it and the in-game search will not show it, so the player reaches it only by typing the address or by running dirhunter on the host — which is exactly what makes a good hiding place for a clue. If you meant this to be findable normally, turn on “Listed in search” for the page.
