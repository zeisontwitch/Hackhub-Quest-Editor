# Twotter QA Test 7

7th Twotter QA Test with r30

## Install (no coding needed)

1. Copy this whole folder into the game's `mods/` directory.
2. Start HackHub — the mod loads from `dist/mod.js`.

## Rebuild (optional, for programmers)

`src/index.ts` is the same code as `dist/mod.js`. With Node 18+:

```
npm install
npm run build
```

## What the editor compiled for you

- Quests: QATest7
- Websites: none
- Permissions requested: none

## Twotter accounts

This mod checks its own Twotter accounts when it loads and fills in any
field the game left unset (name, surname, banner, joined date …). An unset
field there crashes Twotter's search — including in saves made before this
version — so if search has been crashing, installing this mod and loading
the save repairs those records. Look for `[quest-editor] repaired Twotter
account` in the game log.

## Notes

- Everything compiled cleanly. Have fun.
